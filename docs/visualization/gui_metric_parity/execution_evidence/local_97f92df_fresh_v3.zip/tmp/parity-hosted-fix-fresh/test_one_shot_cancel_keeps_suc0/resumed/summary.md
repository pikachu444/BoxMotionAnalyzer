# Regression execution

Last Reviewed: 2026-11-12

Tier: representative / verdict: pass / exit: 0
Source: 97f92df772e0f7776d37a6b41bf7f3469fe7fc0f / dirty: False
Scope: Explicit selected scenes only
Coverage: {'loaded': 6, 'approved': 6, 'selected': 2, 'started': 1, 'completed': 2, 'fresh': 1, 'reused': 1, 'failed': 0, 'unexecuted': 4, 'required': 2, 'evaluable': 2, 'passed': 2}
Numerical acceptance: Approved PUB02 gates apply only to selected production comparisons
Cache origin: {'status': 'explicit_reuse', 'predecessor': {'status': 'requested', 'run_id': 'd6147dd2-b5ac-45c1-8884-1b783f102a22', 'report_sha256': '264a4c77d717ea2b43a50425e7d793b4e91f96ef231c5694162bd9dd62fc78bb', 'reason': 'Successful scenes revalidated; failed/incomplete scenes retry fresh'}, 'reason': 'Only successfully revalidated representative scenes reused'}
GUI evidence: {'widget': 'not_executed', 'render_buffer': 'not_executed', 'native_window': 'not_executed', 'native_input': 'not_executed', 'human_review': 'pending', 'reason': 'CLI is not native GUI evidence', 'status': 'pending'}
Duration: 8.65137480001431 s / process peak: 586727424 bytes
Optimizer: 80
Experimental: pending #104. Native/human GUI evidence has its own scope.

- run: pass — See JSON evidence
- two_drops: pass — raw_load_detection_replay
- supported_H: pass — raw_load_detection_replay
- handling_only: pass — raw_load_detection_replay
- tracking_OFF: pass — raw_load_detection_replay
- partial: pass — raw_load_detection_replay
- two_flips: pass — raw_load_detection_replay
- two_drops-scene-0: pass — reference_residual_signature
- two_drops-scene-1: pass — reference_residual_signature
- supported_H-scene-0: skipped — Capture tier or outside representative selection
- tracking_OFF-scene-0: skipped — Capture tier or outside representative selection
- partial-scene-0: skipped — Capture tier or outside representative selection
- two_flips-scene-0: skipped — Capture tier or outside representative selection
