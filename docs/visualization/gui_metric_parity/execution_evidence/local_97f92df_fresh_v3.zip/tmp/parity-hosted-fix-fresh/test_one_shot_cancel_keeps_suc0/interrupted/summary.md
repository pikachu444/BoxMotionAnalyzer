# Regression execution

Last Reviewed: 2026-11-12

Tier: representative / verdict: fail / exit: 1
Source: 97f92df772e0f7776d37a6b41bf7f3469fe7fc0f / dirty: False
Scope: Explicit selected scenes only
Coverage: {'loaded': 6, 'approved': 6, 'selected': 2, 'started': 1, 'completed': 1, 'fresh': 1, 'reused': 0, 'failed': 1, 'unexecuted': 5, 'required': 2, 'evaluable': 1, 'passed': 1}
Numerical acceptance: Approved PUB02 gates apply only to selected production comparisons
Cache origin: {'status': 'none', 'predecessor': {'status': 'not_requested', 'reason': 'New immutable attempt'}, 'reason': 'No production results reused'}
GUI evidence: {'widget': 'not_executed', 'render_buffer': 'not_executed', 'native_window': 'not_executed', 'native_input': 'not_executed', 'human_review': 'pending', 'reason': 'CLI is not native GUI evidence', 'status': 'pending'}
Duration: 7.4427770000183955 s / process peak: 586727424 bytes
Optimizer: 80
Experimental: pending #104. Native/human GUI evidence has its own scope.

- run: fail — See JSON evidence
- two_drops: fail — raw_load_detection_replay
- two_drops-scene-0: pass — reference_residual_signature
- two_drops-scene-1: fail — Cancelled before required scene processing; resume in a new attempt.
