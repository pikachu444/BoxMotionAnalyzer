# Regression execution

Last Reviewed: 2026-11-12

Tier: full / verdict: pass / exit: 0
Source: 97f92df772e0f7776d37a6b41bf7f3469fe7fc0f / dirty: False
Scope: Every required public corpus scene fresh
Coverage: {'loaded': 6, 'approved': 6, 'selected': 6, 'started': 6, 'completed': 6, 'fresh': 6, 'reused': 0, 'failed': 0, 'unexecuted': 0, 'required': 6, 'evaluable': 6, 'passed': 6}
Numerical acceptance: Approved PUB02 gates apply only to selected production comparisons
Cache origin: {'status': 'none', 'predecessor': {'status': 'not_requested', 'reason': 'New immutable attempt'}, 'reason': 'No production results reused'}
GUI evidence: {'widget': 'not_executed', 'render_buffer': 'not_executed', 'native_window': 'not_executed', 'native_input': 'not_executed', 'human_review': 'pending', 'reason': 'CLI is not native GUI evidence', 'status': 'pending'}
Duration: 36.66773370001465 s / process peak: 215044096 bytes
Optimizer: 449
Experimental: pending #104. Native/human GUI evidence has its own scope.

- run: pass — See JSON evidence
- two_drops: pass — raw_load_detection_replay
- supported_H: pass — raw_load_detection_replay
- handling_only: pass — raw_load_detection_replay
- tracking_OFF: pass — raw_load_detection_replay
- partial: pass — raw_load_detection_replay
- two_flips: pass — raw_load_detection_replay
- two_drops-scene-0: pass — reference_residual_signature
- two_drops-scene-1: pass — reference_residual_signature
- supported_H-scene-0: pass — reference_residual_signature
- tracking_OFF-scene-0: pass — reference_residual_signature
- partial-scene-0: pass — reference_residual_signature
- two_flips-scene-0: pass — reference_residual_signature
